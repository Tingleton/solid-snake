/* 
HTML5 Responsive Template
Simple Responsive Web Design With CSS3 Media Queries
SOURCE: <a href="http://onlinewebapplication.com/simple-responsive-web-design-with-css3-media-queries/" target="_blank"><i><b>Responsive HTML5 Page Using Media Queries</b></i></a>
http://onlinewebapplication.com/demos/responsive-web-design/
 by onlinewebapplication.com
 */